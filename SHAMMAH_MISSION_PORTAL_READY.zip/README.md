# SHAMMAH MISSION PORTAL

AIC Shammah Mission School results management portal.

## Files
- `index.html` - portal interface

## Important
This version is a working offline prototype and stores data in the browser. For teachers on different phones to submit marks automatically to a Director device, connect the portal to a free online database/authentication service before production use.

## GitHub Pages
After uploading `index.html`:
Settings -> Pages -> Deploy from branch -> main -> /(root) -> Save.
